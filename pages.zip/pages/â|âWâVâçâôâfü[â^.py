from select import select
import streamlit as st
import pandas as pd
from st_aggrid import AgGrid, GridOptionsBuilder, GridUpdateMode
import re
import openpyxl
import xlwt
from io import BytesIO
from pyxlsb import open_workbook as open_xlsb
import xlsxwriter
import datetime
import copy

#データフレーム内に値valがあるか探す
def existence(dataframe,val):
    for i in list(dataframe.columns):
        for j in dataframe[i]:
            if j == val:
                return True
    return False

#--:--を--or--.5に変換
def change(time):
    cut1 = int(time[:time.index(':')])
    cut2 = time[time.index(':')+1:]
    if cut2 == '30':
        ans = cut1 + 0.5
    else:
        ans = cut1
    return ans

#changeの逆
def change2(time):
    cut1 = int(time)
    if time-int(time) == 0.5:
        ans = str(cut1)+':30'
    else:
        ans = str(cut1)+':00'
    return ans

def main():
    st.title('曜日毎のシフト')

    week = ['月曜日','火曜日','水曜日','木曜日','金曜日','土曜日','日曜日','祝日','祝前日']

    st.write('このページでは各曜日、各時間帯で必要な人数を入力して下さい')

    if not existence(st.session_state['dataframe']['Shop_data'],'0'):
        open_list = [i for i in st.session_state['dataframe']['Shop_data'].loc['勤務開始時間'].to_list()]
        close_list = [i for i in st.session_state['dataframe']['Shop_data'].loc['勤務終了時間'].to_list()]

        time_index = [i/10 for i in range(int(min(open_list)*10),int(max(close_list)*10),5)]

        time_index2 = [change2(i)+'~'+change2(i+0.5) for i in time_index]
        
        df_mem = pd.DataFrame(time_index2,columns=[' '],index=time_index)
        if 'necessary_membar' not in st.session_state['dataframe']:
            for i in week:
                index_week = [i/10 for i in range(int(open_list[week.index(i)]*10),int(close_list[week.index(i)]*10),5)]
                sr = pd.Series(1, index=index_week, name=i)
                df_mem = pd.concat([df_mem, sr], axis=1, sort=False)
                st.session_state['dataframe']['necessary_membar'] = df_mem
        else:
            df_mem = st.session_state['dataframe']['necessary_membar']

        gb = GridOptionsBuilder.from_dataframe(df_mem, editable=True)

        gb.configure_columns(week,
            cellEditor='agRichSelectCellEditor',
            cellEditorParams={'values':[1,2,3,4,5,6,7,8,9,10]},
            cellEditorPopup=True
        )

        gb.configure_grid_options(enableRangeSelection=True)

        response = AgGrid(
            df_mem,
            gridOptions=gb.build(),
            allow_unsafe_jscode=True,
            enable_enterprise_modules=True,
            updateMode=GridUpdateMode.VALUE_CHANGED
        )

        df_mem = response['data']

        st.session_state['dataframe']['necessary_membar'] = df_mem.set_axis(time_index,axis=0)
    
    else:
        st.error('先に営業時間を入力してください')

    return

if __name__ == '__main__':
    main()
    