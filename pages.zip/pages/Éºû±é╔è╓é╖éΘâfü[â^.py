import streamlit as st
import pandas as pd

def main():

    if 'con' not in st.session_state:
        st.session_state['con'] = ['0'] * 4

    cons = ['日数','勤務コマ数の上限','勤務コマ数の下限','連勤の上限']

    st.session_state['con'][cons.index('日数')] = st.number_input('勤務表作成日数',7,31,30)
    st.session_state['con'][cons.index('勤務コマ数の上限')] = st.number_input('勤務コマ数の上限',1,48,19)
    st.session_state['con'][cons.index('勤務コマ数の下限')] = st.number_input('勤務コマ数の下限',1,48,6)
    st.session_state['con'][cons.index('連勤の上限')] = st.number_input('連勤の上限',1,31,6)

    df_con = pd.DataFrame(st.session_state['con'],columns=['値'],index=cons)
    st.session_state['dataframe']['constraint_data'] = df_con.T

    st.dataframe(df_con.T)

    if 'parameter' not in st.session_state:
        st.session_state['parameter'] = ['0'] * 4

    para = ['総給料','ポジション移動','希望総給料とのずれ','不足コマ数']

    st.session_state['parameter'][para.index('総給料')] = st.number_input('総給料',1,5,1)
    st.session_state['parameter'][para.index('ポジション移動')] = st.number_input('ポジション移動',1,5,1)
    st.session_state['parameter'][para.index('希望総給料とのずれ')] = st.number_input('希望総給料とのずれ',1,5,3)
    st.session_state['parameter'][para.index('不足コマ数')] = st.number_input('不足コマ数',1,5,2)

    df_para = pd.DataFrame(st.session_state['parameter'],columns=['重み'],index=para)
    st.session_state['dataframe']['parameter'] = df_para.T

    st.dataframe(df_para.T)

if __name__ == '__main__':
    main()