from ast import Add
import streamlit as st
import pandas as pd
import openpyxl
import xlwt
from io import BytesIO
from pyxlsb import open_workbook as open_xlsb
import xlsxwriter
import datetime
from select import select
import streamlit as st
import pandas as pd
from st_aggrid import AgGrid, GridOptionsBuilder, GridUpdateMode
import re
import itertools
import copy
import numpy as np

st.title('スタッフデータ')
st.write('<span style="color:red;background:pink">店舗データのポジションを必ず先に入力して下さい</span>',unsafe_allow_html=True)

def main():
    
    staff_index = ['スタッフ名','責任者','時給','希望総給与','属性','ポジション']+list(st.session_state['dataframe']['Position_data'].columns)
    
    staff_input = st.text_input('スタッフ名を入力してください')

    if st.checkbox(str(staff_input)+'が店長ならチェックを入れてください'):
        cost_input = 0
        att_input = '店長'
        re_input = '〇'
    elif st.checkbox(str(staff_input)+'が社員ならチェックを入れてください'):
        cost_input = 0
        att_input = '社員'
        re_input = '〇'
    else:
        if st.checkbox(str(staff_input)+'が責任者ならチェックを入れてください'):
            re_input = '〇'
        else:
            re_input = '×'
        cost_input = st.text_input(str(staff_input)+'の時給を入力してください')
        if cost_input != '':
            try:
                cost_input = int(cost_input)
            except ValueError:
                st.error('時給は数字で入力してください!')
        att_input = st.selectbox(str(staff_input)+'の属性を選択してください',st.session_state['att'])
    position_input = st.multiselect(str(staff_input)+'の勤務可能ポジションを選択してください',st.session_state['position'])

    if st.button('スタッフのデータを追加',key=2):
        if staff_input == '':
            st.error('スタッフ名を入力してください!')
        elif cost_input == '':
            st.error('時給を入力してください!')
        elif position_input == []:
            st.error('勤務可能ポジションを入力してください!')
        else:
            staff_sr = pd.Series([staff_input,re_input,cost_input,0,att_input,'']+['〇' if i in position_input else '×' for i in st.session_state['position']],
                                    index=staff_index,
                                    name=staff_input)
            if 'Staff_names' not in st.session_state['dataframe'].keys():
                st.session_state['dataframe']['Staff_names'] = pd.DataFrame(staff_sr).T

            else:
                st.session_state['dataframe']['Staff_names'].loc[staff_input] = staff_sr
            
    st.session_state['staffs'] = list(st.session_state['dataframe']['Staff_names'].index)

    if 'Staff_names' in st.session_state['dataframe'].keys():
    
        gb = GridOptionsBuilder.from_dataframe(st.session_state['dataframe']['Staff_names'], editable=True)

        gb.configure_selection(selection_mode="multiple", use_checkbox=True)

        staff = AgGrid(st.session_state['dataframe']['Staff_names'],
                        gridOptions=gb.build(),
                        fit_columns_on_grid_load=False,
                        height=150,
                        update_mode=GridUpdateMode.VALUE_CHANGED|GridUpdateMode.SELECTION_CHANGED)
        
        st.session_state['dataframe']['Staff_names'] = staff['data']

        st.session_state['select_staff'] = staff['selected_rows']

        if st.button('選択したスタッフを削除'):
            if len(st.session_state['select_staff']) != 0:
                del_list = [i['rowIndex'] for i in st.session_state['select_staff']]
                st.session_state['dataframe']['Staff_names'] = st.session_state['dataframe']['Staff_names'].drop(del_list)

        st.session_state['dataframe']['Staff_names'] = st.session_state['dataframe']['Staff_names'].set_index('スタッフ名', drop=False)

if __name__ == '__main__':
    main()