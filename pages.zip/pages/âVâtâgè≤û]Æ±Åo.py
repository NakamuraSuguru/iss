from select import select
import streamlit as st
import pandas as pd
from st_aggrid import AgGrid, GridOptionsBuilder, GridUpdateMode
import re
import openpyxl
import xlwt
from io import BytesIO
from pyxlsb import open_workbook as open_xlsb
import xlsxwriter
import datetime

#--:--を--or--.5に変換
def change(time):
    cut1 = int(time[:time.index(':')])
    cut2 = time[time.index(':')+1:]
    if cut2 == '30':
        ans = cut1 + 0.5
    else:
        ans = cut1
    return ans

#changeの逆
def change2(time):
    cut1 = int(time)
    if time-int(time) == 0.5:
        ans = str(cut1)+':30'
    else:
        ans = str(cut1)+':00'
    return ans

#データフレーム内に値valがあるか探す
def existence(dataframe,val):
    for i in list(dataframe.columns):
        for j in dataframe[i]:
            if j == val:
                return True
    return False

#seriesの生成
def make_series(start,end,sr_name,time_index):
    sr = pd.Series('×',index=time_index,name=sr_name)
    if start != '休み' or end != '休み':
        start = change(start)
        end = change(end)
        for i in time_index[time_index.index(start):time_index.index(end)]:
            sr[i] = '〇'
    return sr

def main():
    if existence(st.session_state['dataframe']['Shop_data'],'0'):
        st.error('先に営業時間を入力してください')
    else:
        if 'd_shift' not in st.session_state:
            st.session_state['d_shift'] = {}
        staff = st.selectbox('シフト希望を提出するスタッフを選択してください',st.session_state['staffs']) 
        if staff in st.session_state['d_shift'].keys():
            st.write('シフト希望提出済み')
            st.dataframe(st.session_state['d_shift'][staff])
        upload_file = st.file_uploader(str(staff)+"のシフト希望をアップロードしてください", type='xlsx')
        open_list = [i for i in st.session_state['dataframe']['Shop_data'].loc['勤務開始時間'].to_list()]
        close_list = [i for i in st.session_state['dataframe']['Shop_data'].loc['勤務終了時間'].to_list()]
        time_index = [i/10 for i in range(int(min(open_list)*10),int((max(close_list)+0.5)*10),5)]
        if upload_file is not None:
            d_df = pd.read_excel(upload_file,header=None,names=['0','1','2','3','4','5','6','7','8','9'],index_col=0)
            d_cost = d_df.at['希望総給料','1']
            d_df = d_df.iloc[d_df.index.get_loc('日付')+1:,:4]
            s_h = make_series(d_df.at[d_df.index[0],'2'],d_df.at[d_df.index[0],'4'],d_df.index[0],time_index)
            for i in d_df.index[1:]:
                sr = make_series(d_df.at[i,'2'],d_df.at[i,'4'],i,time_index)
                s_h = pd.concat([s_h,sr],axis=1)
            st.dataframe(s_h)
            if st.button('提出',key=1):
                st.session_state['d_shift'][staff] = s_h
                st.session_state['dataframe']['Staff_names'].at[staff,'希望総給与'] = d_cost
                st.write('提出完了!')
    return

if __name__ == '__main__':
    main()